package com.dicoding.mystory.ui.story

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.navigation.findNavController
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.dicoding.mystory.data.model.Story
import com.dicoding.mystory.databinding.ItemRowStoryBinding
import com.dicoding.mystory.helper.withDateFormat

class StoryAdapter(
    private var listStory: List<Story>
) : RecyclerView.Adapter<StoryAdapter.ViewHolder>() {

    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): ViewHolder {
        val binding =
            ItemRowStoryBinding.inflate(LayoutInflater.from(viewGroup.context), viewGroup, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(viewHolder: ViewHolder, position: Int) {
        val (id, name, description, photo_url, createdAt, lat, lon) = listStory[position]

        Glide.with(viewHolder.itemView.context)
            .load(photo_url)
            .apply(RequestOptions())
            .into(viewHolder.binding.imgPhotoStory)

        viewHolder.binding.tvName.text = name
        viewHolder.binding.tvCreateAt.withDateFormat(createdAt)
        viewHolder.binding.tvDescription.text = description

        viewHolder.itemView.setOnClickListener {
            val toDetailFragment = StoryFragmentDirections.actionStoryFragmentToDetailFragment(listStory[position])
            viewHolder.itemView.findNavController().navigate(toDetailFragment)
        }
    }

    override fun getItemCount(): Int = listStory.size

    class ViewHolder(var binding: ItemRowStoryBinding) : RecyclerView.ViewHolder(binding.root)

    fun updateData(newData: List<Story>) {
        listStory = newData
        notifyDataSetChanged()
    }
}